// procédures pour Moodle
function GoToMoodleHomePage()
{
    window.location.href="/"
}
